'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { FileText, Quote, ListChecks, Sparkles, BookOpen, Clock, ArrowRight, CheckCircle2 } from 'lucide-react';
import type { Language } from '@/lib/i18n';

export default function InterviewUseCasePage() {
  const [currentLang, setCurrentLang] = useState<Language>('en');

  return (
    <div className="flex min-h-screen flex-col">
      <Header currentLang={currentLang} onLanguageChange={setCurrentLang} />

      <main className="flex-1">
        <section className="border-b bg-gradient-to-b from-background to-muted/20 py-20 md:py-28">
          <div className="container mx-auto px-4">
            <div className="mx-auto max-w-4xl text-center">
              <div className="mb-6 inline-flex items-center rounded-full border bg-background px-4 py-2 text-sm shadow-sm">
                <FileText className="mr-2 h-4 w-4 text-primary" />
                <span>Built for Journalists & Writers</span>
              </div>

              <h1 className="mb-6 text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
                Transform Interviews into
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Story-Ready Content</span>
              </h1>

              <p className="mb-10 text-lg text-muted-foreground sm:text-xl">
                Stop spending hours transcribing interviews. Get accurate transcriptions, key quotes, and article structure suggestions in minutes.
              </p>

              <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Link href="/app/upload">
                  <Button size="lg" className="h-12 px-8 text-base">
                    Try Free
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/features">
                  <Button size="lg" variant="outline" className="h-12 px-8 text-base">
                    See All Features
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className="border-b py-20">
          <div className="container mx-auto px-4">
            <div className="mb-16 text-center">
              <h2 className="mb-4 text-3xl font-bold sm:text-4xl">Interview Template Features</h2>
              <p className="text-lg text-muted-foreground">
                Everything you need to turn raw interviews into published articles
              </p>
            </div>

            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10">
                    <Quote className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Best Quotes Extraction</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    AI identifies the most impactful quotes with context about when and how to use them. No more hunting through transcripts for that perfect soundbite.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-accent/10">
                    <ListChecks className="h-7 w-7 text-accent" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Fact-Checking Checklist</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Automatically generates a list of claims and statements that need verification, helping you maintain journalistic integrity and accuracy.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10">
                    <BookOpen className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Article Structure Suggestions</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Get AI-powered recommendations for your lede, main body structure, and conclusion based on the interview content and news value.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-accent/10">
                    <Sparkles className="h-7 w-7 text-accent" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Key Themes & Topics</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Content organized by main themes with supporting details and quotes, making it easy to structure your article by topic.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10">
                    <Clock className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Timeline & Highlights</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Timestamps for key moments in the interview, making it easy to revisit important sections of the original recording.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-accent/10">
                    <FileText className="h-7 w-7 text-accent" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Follow-Up Questions</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    AI suggests follow-up questions based on gaps or interesting angles mentioned in the interview.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="border-b bg-muted/30 py-20">
          <div className="container mx-auto px-4">
            <div className="mb-16 text-center">
              <h2 className="mb-4 text-3xl font-bold sm:text-4xl">What You'll Get</h2>
              <p className="text-lg text-muted-foreground">
                A comprehensive summary tailored for journalistic work
              </p>
            </div>

            <div className="mx-auto max-w-3xl">
              <Card className="border-2">
                <CardContent className="p-8">
                  <div className="space-y-6">
                    <div className="flex items-start">
                      <div className="mr-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                        1
                      </div>
                      <div>
                        <h3 className="mb-2 text-lg font-semibold">Interviewee Information & Core Themes</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          Subject background, interview context, and main topics covered at a glance.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="mr-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                        2
                      </div>
                      <div>
                        <h3 className="mb-2 text-lg font-semibold">Core Insights & News Value</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          What's newsworthy, what's the angle, and why readers will care.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="mr-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                        3
                      </div>
                      <div>
                        <h3 className="mb-2 text-lg font-semibold">Key Quotes with Context</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          The best quotes highlighted with suggestions on when and where to use them in your article.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="mr-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                        4
                      </div>
                      <div>
                        <h3 className="mb-2 text-lg font-semibold">Topic-Organized Content</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          All content organized by theme with relevant quotes and details grouped together.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="mr-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                        5
                      </div>
                      <div>
                        <h3 className="mb-2 text-lg font-semibold">Fact-Check Items</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          A prioritized list of claims, statistics, and statements to verify before publication.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="mr-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                        6
                      </div>
                      <div>
                        <h3 className="mb-2 text-lg font-semibold">Article Structure Recommendations</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          Suggested lede, body structure, and conclusion approach based on the content.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="border-b py-20">
          <div className="container mx-auto px-4">
            <div className="mb-16 text-center">
              <h2 className="mb-4 text-3xl font-bold sm:text-4xl">Perfect For</h2>
            </div>

            <div className="mx-auto grid max-w-5xl gap-8 md:grid-cols-3">
              <Card className="border-2">
                <CardContent className="p-6">
                  <h3 className="mb-4 text-xl font-semibold">Freelance Journalists</h3>
                  <ul className="space-y-3 text-sm text-muted-foreground">
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Turn around articles faster</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Take on more assignments</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Never miss key quotes</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-2">
                <CardContent className="p-6">
                  <h3 className="mb-4 text-xl font-semibold">Magazine Writers</h3>
                  <ul className="space-y-3 text-sm text-muted-foreground">
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Structure long-form pieces</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Identify narrative threads</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Find the compelling angles</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-2">
                <CardContent className="p-6">
                  <h3 className="mb-4 text-xl font-semibold">Content Creators</h3>
                  <ul className="space-y-3 text-sm text-muted-foreground">
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Repurpose podcast interviews</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Create blog content faster</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Extract social media quotes</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="mx-auto max-w-3xl rounded-2xl border-2 border-primary bg-gradient-to-br from-primary/5 to-accent/5 p-12 text-center shadow-xl">
              <h2 className="mb-4 text-3xl font-bold sm:text-4xl">
                Ready to Transform Your Interviews?
              </h2>
              <p className="mb-8 text-lg text-muted-foreground">
                Start with 3 free transcriptions. Experience the interview template today.
              </p>
              <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Link href="/app/upload">
                  <Button size="lg" className="h-12 px-8">
                    Start Free
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/use-cases/sales">
                  <Button size="lg" variant="outline" className="h-12 px-8">
                    View Sales Use Case
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
