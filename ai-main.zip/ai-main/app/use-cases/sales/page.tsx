'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { Target, TrendingUp, Users, AlertCircle, Calendar, DollarSign, ArrowRight, CheckCircle2 } from 'lucide-react';
import type { Language } from '@/lib/i18n';

export default function SalesUseCasePage() {
  const [currentLang, setCurrentLang] = useState<Language>('en');

  return (
    <div className="flex min-h-screen flex-col">
      <Header currentLang={currentLang} onLanguageChange={setCurrentLang} />

      <main className="flex-1">
        <section className="border-b bg-gradient-to-b from-background to-muted/20 py-20 md:py-28">
          <div className="container mx-auto px-4">
            <div className="mx-auto max-w-4xl text-center">
              <div className="mb-6 inline-flex items-center rounded-full border bg-background px-4 py-2 text-sm shadow-sm">
                <Target className="mr-2 h-4 w-4 text-primary" />
                <span>Built for Sales & Insurance Professionals</span>
              </div>

              <h1 className="mb-6 text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
                Never Miss a Deal Detail
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Again</span>
              </h1>

              <p className="mb-10 text-lg text-muted-foreground sm:text-xl">
                Transform client calls into actionable insights. Track needs, objections, budget signals, and next steps automatically with AI.
              </p>

              <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Link href="/app/upload">
                  <Button size="lg" className="h-12 px-8 text-base">
                    Try Free
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/features">
                  <Button size="lg" variant="outline" className="h-12 px-8 text-base">
                    See All Features
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className="border-b py-20">
          <div className="container mx-auto px-4">
            <div className="mb-16 text-center">
              <h2 className="mb-4 text-3xl font-bold sm:text-4xl">Sales Template Features</h2>
              <p className="text-lg text-muted-foreground">
                Everything you need to close more deals and track client relationships
              </p>
            </div>

            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10">
                    <Users className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Client Needs Analysis</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Automatically extract and categorize client needs into core, secondary, and potential requirements. Never miss what the client is really asking for.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-accent/10">
                    <AlertCircle className="h-7 w-7 text-accent" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Objection Tracking</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Capture every objection with your response and current status. Review and refine your approach for future calls.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10">
                    <DollarSign className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Budget & Decision Insights</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Extract budget ranges, decision-maker information, approval process, and timeline signals automatically.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-accent/10">
                    <Calendar className="h-7 w-7 text-accent" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Action Items & Follow-Ups</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Clear action items for you and your client with deadlines and responsible parties. Keep deals moving forward.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10">
                    <TrendingUp className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Deal Probability Assessment</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    AI evaluates deal strength based on the conversation, highlighting risks and opportunities you might have missed.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-accent/10">
                    <Target className="h-7 w-7 text-accent" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Key Conversation Moments</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Highlights critical dialogue around needs, budget, decision-making, and competition for easy reference.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="border-b bg-muted/30 py-20">
          <div className="container mx-auto px-4">
            <div className="mb-16 text-center">
              <h2 className="mb-4 text-3xl font-bold sm:text-4xl">What You'll Get</h2>
              <p className="text-lg text-muted-foreground">
                A comprehensive call analysis optimized for sales professionals
              </p>
            </div>

            <div className="mx-auto max-w-3xl">
              <Card className="border-2">
                <CardContent className="p-8">
                  <div className="space-y-6">
                    <div className="flex items-start">
                      <div className="mr-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                        1
                      </div>
                      <div>
                        <h3 className="mb-2 text-lg font-semibold">Client Profile & Call Context</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          Client details, call type, current deal stage, and overall sentiment assessment.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="mr-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                        2
                      </div>
                      <div>
                        <h3 className="mb-2 text-lg font-semibold">Needs Breakdown</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          Core requirements, secondary needs, and potential upsell opportunities identified from the conversation.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="mr-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                        3
                      </div>
                      <div>
                        <h3 className="mb-2 text-lg font-semibold">Objections & Concerns</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          Every objection captured with your response and status. See what's resolved and what needs work.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="mr-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                        4
                      </div>
                      <div>
                        <h3 className="mb-2 text-lg font-semibold">Budget & Decision Intelligence</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          Budget signals, decision-maker identification, approval process, and purchase timeline.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="mr-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                        5
                      </div>
                      <div>
                        <h3 className="mb-2 text-lg font-semibold">Action Plan</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          Clear next steps for both parties with owners and deadlines to keep momentum.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="mr-4 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                        6
                      </div>
                      <div>
                        <h3 className="mb-2 text-lg font-semibold">Deal Assessment & Strategy</h3>
                        <p className="text-muted-foreground leading-relaxed">
                          Probability rating, competitive threats, risk factors, and recommended strategies to close.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="border-b py-20">
          <div className="container mx-auto px-4">
            <div className="mb-16 text-center">
              <h2 className="mb-4 text-3xl font-bold sm:text-4xl">Perfect For</h2>
            </div>

            <div className="mx-auto grid max-w-5xl gap-8 md:grid-cols-3">
              <Card className="border-2">
                <CardContent className="p-6">
                  <h3 className="mb-4 text-xl font-semibold">B2B Sales Reps</h3>
                  <ul className="space-y-3 text-sm text-muted-foreground">
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Track complex deal cycles</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Identify decision-makers</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Forecast more accurately</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-2">
                <CardContent className="p-6">
                  <h3 className="mb-4 text-xl font-semibold">Insurance Brokers</h3>
                  <ul className="space-y-3 text-sm text-muted-foreground">
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Document client needs</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Track policy discussions</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Ensure compliance</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-2">
                <CardContent className="p-6">
                  <h3 className="mb-4 text-xl font-semibold">Account Executives</h3>
                  <ul className="space-y-3 text-sm text-muted-foreground">
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Manage multiple accounts</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Spot upsell opportunities</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Reduce churn risk</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="mx-auto max-w-3xl rounded-2xl border-2 border-primary bg-gradient-to-br from-primary/5 to-accent/5 p-12 text-center shadow-xl">
              <h2 className="mb-4 text-3xl font-bold sm:text-4xl">
                Ready to Close More Deals?
              </h2>
              <p className="mb-8 text-lg text-muted-foreground">
                Start with 3 free transcriptions. Experience the sales template today.
              </p>
              <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Link href="/app/upload">
                  <Button size="lg" className="h-12 px-8">
                    Start Free
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/use-cases/interview">
                  <Button size="lg" variant="outline" className="h-12 px-8">
                    View Interview Use Case
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
