'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { CheckCircle2, X, ArrowRight } from 'lucide-react';
import type { Language } from '@/lib/i18n';

export default function PricingPage() {
  const [currentLang, setCurrentLang] = useState<Language>('en');

  return (
    <div className="flex min-h-screen flex-col">
      <Header currentLang={currentLang} onLanguageChange={setCurrentLang} />

      <main className="flex-1">
        <section className="border-b bg-gradient-to-b from-background to-muted/20 py-20">
          <div className="container mx-auto px-4">
            <div className="mx-auto max-w-3xl text-center">
              <h1 className="mb-6 text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
                Simple,
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Transparent Pricing</span>
              </h1>
              <p className="text-lg text-muted-foreground sm:text-xl">
                Start free with no credit card required. Upgrade when you need more capacity.
              </p>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="mx-auto grid max-w-6xl gap-8 lg:grid-cols-2">
              <Card className="relative border-2 transition-all hover:shadow-lg">
                <CardHeader className="pb-8">
                  <CardTitle className="text-2xl">Free</CardTitle>
                  <div className="mt-4">
                    <span className="text-5xl font-bold">$0</span>
                    <span className="text-muted-foreground">/month</span>
                  </div>
                  <p className="mt-2 text-muted-foreground">
                    Perfect for trying out AudioScribe
                  </p>
                </CardHeader>
                <CardContent>
                  <Link href="/auth/register">
                    <Button variant="outline" className="mb-8 w-full" size="lg">
                      Start Free
                    </Button>
                  </Link>

                  <div className="space-y-4">
                    <div className="flex items-start">
                      <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                      <div>
                        <p className="font-medium">3 Transcriptions per month</p>
                        <p className="text-sm text-muted-foreground">Up to 60 minutes each</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                      <div>
                        <p className="font-medium">1 AI Summary per month</p>
                        <p className="text-sm text-muted-foreground">Universal template only</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                      <div>
                        <p className="font-medium">Basic audio formats</p>
                        <p className="text-sm text-muted-foreground">MP3, M4A, WAV</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                      <div>
                        <p className="font-medium">TXT export</p>
                        <p className="text-sm text-muted-foreground">Plain text format</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                      <div>
                        <p className="font-medium">7-day file retention</p>
                        <p className="text-sm text-muted-foreground">Auto-deleted after 7 days</p>
                      </div>
                    </div>

                    <div className="flex items-start opacity-50">
                      <X className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-muted-foreground" />
                      <div>
                        <p className="font-medium text-muted-foreground">Specialized templates</p>
                      </div>
                    </div>

                    <div className="flex items-start opacity-50">
                      <X className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-muted-foreground" />
                      <div>
                        <p className="font-medium text-muted-foreground">DOCX & PDF export</p>
                      </div>
                    </div>

                    <div className="flex items-start opacity-50">
                      <X className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-muted-foreground" />
                      <div>
                        <p className="font-medium text-muted-foreground">Priority processing</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="relative border-2 border-primary shadow-xl transition-all hover:shadow-2xl">
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <Badge className="bg-primary px-6 py-1.5 text-sm font-semibold">
                    MOST POPULAR
                  </Badge>
                </div>

                <CardHeader className="pb-8 pt-8">
                  <CardTitle className="text-2xl">Pro</CardTitle>
                  <div className="mt-4">
                    <span className="text-5xl font-bold">$12.99</span>
                    <span className="text-muted-foreground">/month</span>
                  </div>
                  <p className="mt-2 text-muted-foreground">
                    For professionals who need more
                  </p>
                </CardHeader>
                <CardContent>
                  <Link href="/app/billing">
                    <Button className="mb-8 w-full" size="lg">
                      Upgrade to Pro
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                  </Link>

                  <div className="space-y-4">
                    <div className="flex items-start">
                      <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                      <div>
                        <p className="font-medium">1,200 minutes per month</p>
                        <p className="text-sm text-muted-foreground">Shared between transcription & summaries</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                      <div>
                        <p className="font-medium">Unlimited file length</p>
                        <p className="text-sm text-muted-foreground">Process files of any duration</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                      <div>
                        <p className="font-medium">All audio formats</p>
                        <p className="text-sm text-muted-foreground">MP3, M4A, WAV, OGG, FLAC</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                      <div>
                        <p className="font-medium">All 3 specialized templates</p>
                        <p className="text-sm text-muted-foreground">Universal, Interview, Sales</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                      <div>
                        <p className="font-medium">All export formats</p>
                        <p className="text-sm text-muted-foreground">TXT, DOCX, PDF</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                      <div>
                        <p className="font-medium">30-day file retention</p>
                        <p className="text-sm text-muted-foreground">Extended storage period</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                      <div>
                        <p className="font-medium">Priority processing</p>
                        <p className="text-sm text-muted-foreground">Faster turnaround times</p>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <CheckCircle2 className="mr-3 mt-0.5 h-5 w-5 flex-shrink-0 text-accent" />
                      <div>
                        <p className="font-medium">Email support</p>
                        <p className="text-sm text-muted-foreground">Priority customer service</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="mx-auto mt-12 max-w-3xl text-center">
              <p className="text-sm text-muted-foreground">
                All plans include secure file storage, automatic deletion, and end-to-end encryption.
                Cancel anytime with no questions asked.
              </p>
            </div>
          </div>
        </section>

        <section className="border-t bg-muted/30 py-20">
          <div className="container mx-auto px-4">
            <div className="mx-auto max-w-3xl">
              <h2 className="mb-12 text-center text-3xl font-bold">Frequently Asked Questions</h2>

              <div className="space-y-8">
                <div>
                  <h3 className="mb-2 text-lg font-semibold">How does the minute quota work for Pro?</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Pro users get 1,200 minutes per month shared between transcription and summaries. Transcription deducts the audio duration (e.g., 30-minute file = 30 minutes). Each AI summary deducts a fixed 5 minutes. Your quota resets monthly on your billing date.
                  </p>
                </div>

                <div>
                  <h3 className="mb-2 text-lg font-semibold">Can I upgrade or downgrade anytime?</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Yes! You can upgrade to Pro at any time to get immediate access to all features. If you downgrade, you'll continue to have Pro access until the end of your current billing period.
                  </p>
                </div>

                <div>
                  <h3 className="mb-2 text-lg font-semibold">What happens to my files after the retention period?</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Files are automatically deleted after 7 days (Free) or 30 days (Pro) to protect your privacy. Make sure to download any files you need before the expiration date. We don't provide recovery after deletion.
                  </p>
                </div>

                <div>
                  <h3 className="mb-2 text-lg font-semibold">Do you offer refunds?</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    We offer a 30-day money-back guarantee. If you're not satisfied with AudioScribe within the first 30 days, contact us for a full refund, no questions asked.
                  </p>
                </div>

                <div>
                  <h3 className="mb-2 text-lg font-semibold">What audio formats do you support?</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Free users can upload MP3, M4A, and WAV files. Pro users get additional support for OGG and FLAC formats. All formats maintain the original audio quality during processing.
                  </p>
                </div>

                <div>
                  <h3 className="mb-2 text-lg font-semibold">Is my data secure?</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Absolutely. All files are encrypted during upload, processing, and storage. We never use your data for AI training, and files are automatically deleted after the retention period. We're fully GDPR compliant.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="border-t py-20">
          <div className="container mx-auto px-4">
            <div className="mx-auto max-w-3xl rounded-2xl border-2 border-primary bg-gradient-to-br from-primary/5 to-accent/5 p-12 text-center shadow-xl">
              <h2 className="mb-4 text-3xl font-bold sm:text-4xl">
                Ready to Get Started?
              </h2>
              <p className="mb-8 text-lg text-muted-foreground">
                Try AudioScribe free today. No credit card required.
              </p>
              <Link href="/app/upload">
                <Button size="lg" className="h-12 px-8">
                  Start Free Trial
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
