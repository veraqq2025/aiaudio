'use client';

import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AppHeader } from '@/components/layout/app-header';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Upload, FileAudio, X, CheckCircle2, AlertCircle, Info } from 'lucide-react';

export default function UploadPage() {
  const [file, setFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const userType = 'free' as 'free' | 'pro';
  const remainingTranscriptions = 2;
  const maxDuration = 60;

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    setError(null);

    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      validateAndSetFile(droppedFile);
    }
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setError(null);
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      validateAndSetFile(selectedFile);
    }
  }, []);

  const validateAndSetFile = (file: File) => {
    const allowedFormats = userType === 'free'
      ? ['audio/mpeg', 'audio/mp3', 'audio/m4a', 'audio/wav', 'audio/x-m4a', 'audio/x-wav']
      : ['audio/mpeg', 'audio/mp3', 'audio/m4a', 'audio/wav', 'audio/ogg', 'audio/flac', 'audio/x-m4a', 'audio/x-wav'];

    if (!allowedFormats.includes(file.type) && !file.name.match(/\.(mp3|m4a|wav|ogg|flac)$/i)) {
      setError('Unsupported file format. Please upload a supported audio format.');
      return;
    }

    const maxSize = 500 * 1024 * 1024;
    if (file.size > maxSize) {
      setError('File size exceeds 500MB limit.');
      return;
    }

    setFile(file);
  };

  const handleRemoveFile = () => {
    setFile(null);
    setError(null);
  };

  const handleStartTranscription = () => {
    if (!file) return;
  };

  return (
    <div className="flex min-h-screen flex-col">
      <AppHeader />

      <main className="flex-1 bg-muted/20">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="mb-2 text-3xl font-bold">Upload Audio</h1>
            <p className="text-muted-foreground">
              Upload your audio file to start transcription
            </p>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Select Audio File</CardTitle>
                  <CardDescription>
                    Drag and drop or click to select your audio file
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {!file ? (
                    <div
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                      className={`relative cursor-pointer rounded-lg border-2 border-dashed p-12 text-center transition-colors ${
                        isDragging
                          ? 'border-primary bg-primary/5'
                          : 'border-muted-foreground/25 hover:border-primary hover:bg-muted/50'
                      }`}
                    >
                      <input
                        type="file"
                        accept={userType === 'free' ? '.mp3,.m4a,.wav' : '.mp3,.m4a,.wav,.ogg,.flac'}
                        onChange={handleFileSelect}
                        className="absolute inset-0 cursor-pointer opacity-0"
                      />
                      <Upload className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
                      <h3 className="mb-2 text-lg font-semibold">
                        Drop your audio file here
                      </h3>
                      <p className="mb-4 text-sm text-muted-foreground">
                        or click to browse
                      </p>
                      <div className="flex flex-wrap items-center justify-center gap-2">
                        <Badge variant="secondary">MP3</Badge>
                        <Badge variant="secondary">M4A</Badge>
                        <Badge variant="secondary">WAV</Badge>
                        {userType === 'pro' && (
                          <>
                            <Badge variant="secondary">OGG</Badge>
                            <Badge variant="secondary">FLAC</Badge>
                          </>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="rounded-lg border-2 border-primary bg-primary/5 p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4">
                          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                            <FileAudio className="h-6 w-6 text-primary" />
                          </div>
                          <div>
                            <h3 className="mb-1 font-semibold">{file.name}</h3>
                            <p className="text-sm text-muted-foreground">
                              {(file.size / 1024 / 1024).toFixed(2)} MB
                            </p>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={handleRemoveFile}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  )}

                  {error && (
                    <Alert variant="destructive" className="mt-4">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  {file && !error && (
                    <div className="mt-6">
                      <Button
                        size="lg"
                        className="w-full"
                        onClick={handleStartTranscription}
                      >
                        Start Transcription
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Your Quota</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="mb-2 flex items-center justify-between">
                      <span className="text-sm font-medium">Transcriptions</span>
                      <Badge variant="secondary">{remainingTranscriptions} left</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {userType === 'free'
                        ? `${remainingTranscriptions} of 3 remaining this month`
                        : 'Unlimited transcriptions'}
                    </p>
                  </div>

                  {userType === 'free' && (
                    <div className="rounded-lg bg-muted p-4">
                      <div className="mb-2 flex items-center space-x-2">
                        <Info className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">Upgrade for More</span>
                      </div>
                      <p className="mb-3 text-xs text-muted-foreground">
                        Pro plan includes 1,200 minutes/month and all features
                      </p>
                      <Button variant="outline" size="sm" className="w-full" asChild>
                        <a href="/pricing">View Plans</a>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">File Requirements</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="flex items-start space-x-2">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                    <div>
                      <p className="font-medium">Supported Formats</p>
                      <p className="text-xs text-muted-foreground">
                        {userType === 'free'
                          ? 'MP3, M4A, WAV'
                          : 'MP3, M4A, WAV, OGG, FLAC'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-2">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                    <div>
                      <p className="font-medium">Maximum Duration</p>
                      <p className="text-xs text-muted-foreground">
                        {userType === 'free'
                          ? 'Up to 60 minutes per file'
                          : 'No limit on file duration'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-2">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                    <div>
                      <p className="font-medium">File Size</p>
                      <p className="text-xs text-muted-foreground">
                        Up to 500 MB per file
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-2">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                    <div>
                      <p className="font-medium">Processing Time</p>
                      <p className="text-xs text-muted-foreground">
                        Usually completes in 2-5 minutes
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
