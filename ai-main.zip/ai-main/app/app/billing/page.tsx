'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AppHeader } from '@/components/layout/app-header';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Crown, CreditCard, Calendar, TrendingUp, ArrowRight } from 'lucide-react';

export default function BillingPage() {
  const currentPlan = 'free';
  const nextBillingDate = '2024-12-05';

  return (
    <div className="flex min-h-screen flex-col">
      <AppHeader />

      <main className="flex-1 bg-muted/20">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="mb-2 text-3xl font-bold">Billing & Subscription</h1>
            <p className="text-muted-foreground">
              Manage your subscription and billing information
            </p>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Current Plan</CardTitle>
                      <CardDescription>
                        {currentPlan === 'free' ? 'Free tier' : 'Pro subscription'}
                      </CardDescription>
                    </div>
                    <Badge variant={currentPlan === 'free' ? 'secondary' : 'default'} className="text-base px-4 py-1">
                      {currentPlan === 'free' ? 'Free' : 'Pro'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  {currentPlan === 'free' ? (
                    <div className="space-y-4">
                      <p className="text-sm text-muted-foreground">
                        You're currently on the free plan with limited features.
                      </p>
                      <div className="rounded-lg border-2 border-primary bg-gradient-to-r from-primary/5 to-accent/5 p-6">
                        <div className="mb-4 flex items-center space-x-3">
                          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                            <Crown className="h-6 w-6 text-primary" />
                          </div>
                          <div>
                            <h3 className="font-semibold">Upgrade to Pro</h3>
                            <p className="text-sm text-muted-foreground">
                              $12.99/month • 1,200 minutes • All features
                            </p>
                          </div>
                        </div>
                        <ul className="mb-6 space-y-2 text-sm">
                          <li className="flex items-center">
                            <TrendingUp className="mr-2 h-4 w-4 text-accent" />
                            <span>1,200 minutes per month</span>
                          </li>
                          <li className="flex items-center">
                            <TrendingUp className="mr-2 h-4 w-4 text-accent" />
                            <span>All 3 specialized templates</span>
                          </li>
                          <li className="flex items-center">
                            <TrendingUp className="mr-2 h-4 w-4 text-accent" />
                            <span>DOCX & PDF export</span>
                          </li>
                          <li className="flex items-center">
                            <TrendingUp className="mr-2 h-4 w-4 text-accent" />
                            <span>30-day file retention</span>
                          </li>
                        </ul>
                        <Link href="/pricing">
                          <Button size="lg" className="w-full">
                            Upgrade Now
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="grid gap-4 sm:grid-cols-2">
                        <div className="rounded-lg border bg-muted/50 p-4">
                          <p className="mb-1 text-sm text-muted-foreground">Monthly Price</p>
                          <p className="text-2xl font-bold">$12.99</p>
                        </div>
                        <div className="rounded-lg border bg-muted/50 p-4">
                          <p className="mb-1 text-sm text-muted-foreground">Next Billing</p>
                          <p className="text-2xl font-bold">{nextBillingDate}</p>
                        </div>
                      </div>
                      <Separator />
                      <Button variant="outline">Manage Subscription</Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Usage This Month</CardTitle>
                  <CardDescription>
                    Track your usage and quota
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {currentPlan === 'free' ? (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Transcriptions</span>
                        <Badge variant="secondary">1 / 3 used</Badge>
                      </div>
                      <Separator />
                      <div className="flex items-center justify-between">
                        <span className="text-sm">AI Summaries</span>
                        <Badge variant="secondary">0 / 1 used</Badge>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Minutes Used</span>
                        <Badge variant="secondary">156 / 1,200</Badge>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                        <div className="h-full bg-primary" style={{ width: '13%' }} />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        1,044 minutes remaining this month
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Payment Method</CardTitle>
                </CardHeader>
                <CardContent>
                  {currentPlan === 'free' ? (
                    <div className="text-center py-6">
                      <CreditCard className="mx-auto mb-3 h-12 w-12 text-muted-foreground/50" />
                      <p className="text-sm text-muted-foreground">
                        No payment method on file
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3 rounded-lg border p-3">
                        <CreditCard className="h-5 w-5 text-muted-foreground" />
                        <div className="flex-1">
                          <p className="text-sm font-medium">•••• •••• •••• 4242</p>
                          <p className="text-xs text-muted-foreground">Expires 12/25</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" className="w-full">
                        Update Card
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Billing History</CardTitle>
                </CardHeader>
                <CardContent>
                  {currentPlan === 'free' ? (
                    <p className="text-center text-sm text-muted-foreground py-4">
                      No billing history
                    </p>
                  ) : (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <div>
                          <p className="font-medium">Nov 2024</p>
                          <p className="text-xs text-muted-foreground">Paid</p>
                        </div>
                        <span className="font-medium">$12.99</span>
                      </div>
                      <Separator />
                      <div className="flex items-center justify-between text-sm">
                        <div>
                          <p className="font-medium">Oct 2024</p>
                          <p className="text-xs text-muted-foreground">Paid</p>
                        </div>
                        <span className="font-medium">$12.99</span>
                      </div>
                      <Separator />
                      <Button variant="ghost" size="sm" className="w-full">
                        View All Invoices
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
