'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AppHeader } from '@/components/layout/app-header';
import { Badge } from '@/components/ui/badge';
import { Upload, FileText, Sparkles, TrendingUp, ArrowRight, Crown } from 'lucide-react';

export default function AppDashboard() {
  const userType = 'free';
  const transcriptionsUsed = 1;
  const transcriptionsLimit = 3;
  const summariesUsed = 0;
  const summariesLimit = 1;

  return (
    <div className="flex min-h-screen flex-col">
      <AppHeader />

      <main className="flex-1 bg-muted/20">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="mb-2 text-3xl font-bold">Dashboard</h1>
            <p className="text-muted-foreground">
              Welcome back! Here's your usage overview.
            </p>
          </div>

          {userType === 'free' && (
            <Card className="mb-8 border-primary bg-gradient-to-r from-primary/5 to-accent/5">
              <CardContent className="flex items-center justify-between p-6">
                <div className="flex items-center space-x-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <Crown className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Upgrade to Pro</h3>
                    <p className="text-sm text-muted-foreground">
                      Get 1,200 minutes/month and unlock all templates
                    </p>
                  </div>
                </div>
                <Link href="/pricing">
                  <Button>
                    Upgrade Now
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}

          <div className="mb-8 grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Transcriptions</span>
                  <Badge variant="secondary">
                    {transcriptionsUsed}/{transcriptionsLimit}
                  </Badge>
                </CardTitle>
                <CardDescription>
                  Monthly transcription quota
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-2 h-2 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{ width: `${(transcriptionsUsed / transcriptionsLimit) * 100}%` }}
                  />
                </div>
                <p className="text-sm text-muted-foreground">
                  {transcriptionsLimit - transcriptionsUsed} transcriptions remaining this month
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>AI Summaries</span>
                  <Badge variant="secondary">
                    {summariesUsed}/{summariesLimit}
                  </Badge>
                </CardTitle>
                <CardDescription>
                  Monthly summary quota
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-2 h-2 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{ width: `${(summariesUsed / summariesLimit) * 100}%` }}
                  />
                </div>
                <p className="text-sm text-muted-foreground">
                  {summariesLimit - summariesUsed} summaries remaining this month
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="mb-8">
            <h2 className="mb-4 text-2xl font-bold">Quick Actions</h2>
            <div className="grid gap-6 md:grid-cols-3">
              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-6">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                    <Upload className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="mb-2 text-lg font-semibold">Upload Audio</h3>
                  <p className="mb-4 text-sm text-muted-foreground">
                    Start a new transcription from your audio files
                  </p>
                  <Link href="/app/upload">
                    <Button className="w-full">
                      Upload File
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-6">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-accent/10">
                    <FileText className="h-6 w-6 text-accent" />
                  </div>
                  <h3 className="mb-2 text-lg font-semibold">View Templates</h3>
                  <p className="mb-4 text-sm text-muted-foreground">
                    Learn about specialized summary templates
                  </p>
                  <Link href="/features">
                    <Button variant="outline" className="w-full">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-6">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                    <TrendingUp className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="mb-2 text-lg font-semibold">Upgrade Plan</h3>
                  <p className="mb-4 text-sm text-muted-foreground">
                    Get unlimited access and all features
                  </p>
                  <Link href="/pricing">
                    <Button variant="outline" className="w-full">
                      View Plans
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Getting Started</CardTitle>
              <CardDescription>
                Make the most of AudioScribe
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    1
                  </div>
                  <div>
                    <h4 className="mb-1 font-semibold">Upload Your First Audio</h4>
                    <p className="text-sm text-muted-foreground">
                      Drag and drop an audio file or select from your device. We support MP3, M4A, WAV, and more.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    2
                  </div>
                  <div>
                    <h4 className="mb-1 font-semibold">Wait for Processing</h4>
                    <p className="text-sm text-muted-foreground">
                      Our AI will transcribe your audio in minutes. You'll see a progress indicator during processing.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    3
                  </div>
                  <div>
                    <h4 className="mb-1 font-semibold">Generate Summary & Export</h4>
                    <p className="text-sm text-muted-foreground">
                      Once transcribed, generate an AI summary and download in your preferred format (TXT, DOCX, or PDF).
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
