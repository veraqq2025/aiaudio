'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AppHeader } from '@/components/layout/app-header';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Download,
  FileText,
  Sparkles,
  Clock,
  FileAudio,
  CheckCircle2,
  Crown,
  AlertCircle,
  ArrowLeft,
} from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export default function ResultPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [selectedTemplate, setSelectedTemplate] = useState<string>('universal');
  const [showBackDialog, setShowBackDialog] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [filename, setFilename] = useState('client-call-2024.mp3');

  useEffect(() => {
    const fileParam = searchParams.get('file');
    if (fileParam) {
      setFilename(decodeURIComponent(fileParam));
    }
  }, [searchParams]);

  const mockData = {
    filename,
    duration: '23:45',
    uploadDate: '2024-11-05',
    expiresIn: '7 days',
    transcription: `This is a sample transcription of the audio file. In a real implementation, this would contain the full transcribed text from the audio recording.\n\nThe transcription would be formatted with proper paragraphs and would capture all spoken content from the recording.\n\nSpeaker 1: Welcome to our discussion today.\n\nSpeaker 2: Thank you for having me. I'm excited to share my insights.\n\nSpeaker 1: Let's dive right in. Can you tell us about your experience?\n\nSpeaker 2: Absolutely. Over the past five years, I've been working in this field and have seen tremendous growth...`,
    hasSummary: false,
    userType: 'free',
  };

  const handleGenerateSummary = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
    }, 3000);
  };

  const handleBackClick = () => {
    setShowBackDialog(true);
  };

  const confirmBack = () => {
    router.push('/');
  };

  const handleExport = (format: string) => {
  };

  return (
    <div className="flex min-h-screen flex-col">
      <AppHeader />

      <main className="flex-1 bg-muted/20">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <Button
              variant="ghost"
              onClick={handleBackClick}
              className="mb-4 -ml-2"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            <h1 className="mb-2 text-3xl font-bold">Transcription Result</h1>
            <p className="text-muted-foreground">
              View your transcription and generate AI summaries
            </p>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-accent/10">
                        <FileAudio className="h-6 w-6 text-accent" />
                      </div>
                      <div>
                        <CardTitle>{mockData.filename}</CardTitle>
                        <CardDescription>
                          {mockData.duration} • Uploaded {mockData.uploadDate}
                        </CardDescription>
                      </div>
                    </div>
                    <Badge variant="secondary" className="flex items-center">
                      <CheckCircle2 className="mr-1 h-3 w-3" />
                      Completed
                    </Badge>
                  </div>
                </CardHeader>
              </Card>

              <Tabs defaultValue="transcription" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="transcription">
                    <FileText className="mr-2 h-4 w-4" />
                    Transcription
                  </TabsTrigger>
                  <TabsTrigger value="summary">
                    <Sparkles className="mr-2 h-4 w-4" />
                    AI Summary
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="transcription">
                  <Card>
                    <CardHeader>
                      <CardTitle>Full Transcription</CardTitle>
                      <CardDescription>
                        Complete text from your audio file
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="prose prose-sm max-w-none">
                        <div className="whitespace-pre-wrap rounded-lg bg-muted p-4 font-mono text-sm">
                          {mockData.transcription}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="summary">
                  <Card>
                    <CardHeader>
                      <CardTitle>AI Summary</CardTitle>
                      <CardDescription>
                        Generate an intelligent summary from your transcription
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {!mockData.hasSummary ? (
                        <div className="py-12 text-center">
                          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                            <Sparkles className="h-8 w-8 text-primary" />
                          </div>
                          <h3 className="mb-2 text-lg font-semibold">
                            Generate AI Summary
                          </h3>
                          <p className="mb-6 text-sm text-muted-foreground">
                            Choose a template and generate an intelligent summary
                          </p>

                          <div className="mb-6 space-y-3">
                            <Button
                              variant={selectedTemplate === 'universal' ? 'default' : 'outline'}
                              className="w-full justify-start"
                              onClick={() => setSelectedTemplate('universal')}
                            >
                              <FileText className="mr-2 h-4 w-4" />
                              Universal Template
                              {mockData.userType === 'free' && (
                                <Badge variant="secondary" className="ml-auto">
                                  Available
                                </Badge>
                              )}
                            </Button>

                            <Button
                              variant={selectedTemplate === 'interview' ? 'default' : 'outline'}
                              className="w-full justify-start"
                              onClick={() => setSelectedTemplate('interview')}
                              disabled={mockData.userType === 'free'}
                            >
                              <FileText className="mr-2 h-4 w-4" />
                              Interview Template
                              {mockData.userType === 'free' && (
                                <Crown className="ml-auto h-4 w-4 text-muted-foreground" />
                              )}
                            </Button>

                            <Button
                              variant={selectedTemplate === 'sales' ? 'default' : 'outline'}
                              className="w-full justify-start"
                              onClick={() => setSelectedTemplate('sales')}
                              disabled={mockData.userType === 'free'}
                            >
                              <FileText className="mr-2 h-4 w-4" />
                              Sales Template
                              {mockData.userType === 'free' && (
                                <Crown className="ml-auto h-4 w-4 text-muted-foreground" />
                              )}
                            </Button>
                          </div>

                          {mockData.userType === 'free' && (
                            <Alert className="mb-6">
                              <AlertCircle className="h-4 w-4" />
                              <AlertDescription>
                                Upgrade to Pro to access Interview and Sales templates
                              </AlertDescription>
                            </Alert>
                          )}

                          <Button
                            size="lg"
                            onClick={handleGenerateSummary}
                            disabled={isGenerating}
                            className="animate-breathe"
                          >
                            {isGenerating ? 'Generating...' : 'Generate Summary'}
                            <Sparkles className="ml-2 h-4 w-4" />
                          </Button>
                        </div>
                      ) : (
                        <div className="prose prose-sm max-w-none">
                          <p className="text-muted-foreground">
                            Summary content would appear here after generation.
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>

            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Export Options</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => handleExport('txt')}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download TXT
                  </Button>

                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => handleExport('docx')}
                    disabled={mockData.userType === 'free'}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download DOCX
                    {mockData.userType === 'free' && (
                      <Crown className="ml-auto h-4 w-4 text-muted-foreground" />
                    )}
                  </Button>

                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => handleExport('pdf')}
                    disabled={mockData.userType === 'free'}
                  >
                    <Download className="mr-2 h-4 w-4" />
                    Download PDF
                    {mockData.userType === 'free' && (
                      <Crown className="ml-auto h-4 w-4 text-muted-foreground" />
                    )}
                  </Button>

                  {mockData.userType === 'free' && (
                    <>
                      <Separator />
                      <div className="rounded-lg bg-muted p-4">
                        <p className="mb-3 text-xs text-muted-foreground">
                          Upgrade to Pro for DOCX and PDF export
                        </p>
                        <Button variant="outline" size="sm" className="w-full" asChild>
                          <a href="/pricing">Upgrade Now</a>
                        </Button>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">File Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Duration</span>
                    <span className="font-medium">{mockData.duration}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Uploaded</span>
                    <span className="font-medium">{mockData.uploadDate}</span>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Expires in</span>
                    <Badge variant="secondary" className="flex items-center">
                      <Clock className="mr-1 h-3 w-3" />
                      {mockData.expiresIn}
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-xs">
                  Files are automatically deleted after {mockData.userType === 'free' ? '7' : '30'} days.
                  Make sure to download before expiration.
                </AlertDescription>
              </Alert>
            </div>
          </div>
        </div>
      </main>

      <AlertDialog open={showBackDialog} onOpenChange={setShowBackDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Leave this page?</AlertDialogTitle>
            <AlertDialogDescription>
              Your transcription results will not be saved. Once you leave, you'll need to process your audio file again. Are you sure you want to go back?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Stay on page</AlertDialogCancel>
            <AlertDialogAction onClick={confirmBack}>Leave page</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
