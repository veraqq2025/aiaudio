'use client';

import { useState } from 'react';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import type { Language } from '@/lib/i18n';

export default function TermsPage() {
  const [currentLang, setCurrentLang] = useState<Language>('en');

  return (
    <div className="flex min-h-screen flex-col">
      <Header currentLang={currentLang} onLanguageChange={setCurrentLang} />

      <main className="flex-1">
        <div className="container mx-auto px-4 py-16">
          <div className="mx-auto max-w-3xl">
            <h1 className="mb-4 text-4xl font-bold">Terms of Service</h1>
            <p className="mb-8 text-muted-foreground">
              Last updated: November 5, 2024
            </p>

            <div className="prose prose-slate max-w-none">
              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Agreement to Terms</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  By accessing or using AudioScribe, you agree to be bound by these Terms of Service. If you do not agree to these terms, you may not use our service.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Service Description</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  AudioScribe provides AI-powered audio transcription and summarization services. We offer both free and paid subscription plans with varying features and usage limits.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Account Registration</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  To use AudioScribe, you must create an account with a valid email address and password. You are responsible for:
                </p>
                <ul className="mb-4 list-disc space-y-2 pl-6 text-muted-foreground">
                  <li>Maintaining the confidentiality of your account credentials</li>
                  <li>All activities that occur under your account</li>
                  <li>Notifying us immediately of any unauthorized access</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Subscription Plans</h2>
                <h3 className="mb-3 text-xl font-semibold">Free Plan</h3>
                <ul className="mb-4 list-disc space-y-2 pl-6 text-muted-foreground">
                  <li>3 transcriptions per month (up to 60 minutes each)</li>
                  <li>1 AI summary per month</li>
                  <li>7-day file retention</li>
                  <li>TXT export only</li>
                </ul>
                <h3 className="mb-3 text-xl font-semibold">Pro Plan ($12.99/month)</h3>
                <ul className="mb-4 list-disc space-y-2 pl-6 text-muted-foreground">
                  <li>1,200 minutes per month (shared between transcription and summaries)</li>
                  <li>Unlimited file length</li>
                  <li>All specialized templates</li>
                  <li>All export formats (TXT, DOCX, PDF)</li>
                  <li>30-day file retention</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Payment and Billing</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  Pro subscriptions are billed monthly. You authorize us to charge your payment method on a recurring basis. You may cancel your subscription at any time, and you will retain Pro access until the end of your current billing period.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Refund Policy</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  We offer a 30-day money-back guarantee for new Pro subscriptions. If you are not satisfied within the first 30 days, contact us for a full refund.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Acceptable Use</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  You agree not to:
                </p>
                <ul className="mb-4 list-disc space-y-2 pl-6 text-muted-foreground">
                  <li>Upload content that is illegal, harmful, or violates third-party rights</li>
                  <li>Attempt to circumvent usage limits or quotas</li>
                  <li>Reverse engineer or attempt to extract our AI models</li>
                  <li>Use the service for any unlawful purpose</li>
                  <li>Share account credentials with others</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Content Ownership</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  You retain all rights to the audio files you upload and the transcriptions we generate. We do not claim ownership of your content. By using our service, you grant us a limited license to process your files for the purpose of providing transcription and summarization services.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Data Retention</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  Files are automatically deleted according to your plan's retention period (7 days for Free, 30 days for Pro). We do not provide recovery services for deleted files.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Service Availability</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  We strive to maintain high availability but do not guarantee uninterrupted service. We reserve the right to modify or discontinue the service with reasonable notice.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Limitation of Liability</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  AudioScribe is provided "as is" without warranties. We are not liable for any indirect, incidental, or consequential damages arising from your use of the service.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Changes to Terms</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  We may update these terms from time to time. We will notify you of significant changes via email or through the service.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Contact</h2>
                <p className="leading-relaxed text-muted-foreground">
                  For questions about these Terms of Service, please contact us at support@audioscribe.app.
                </p>
              </section>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
