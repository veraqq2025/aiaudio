'use client';

import { useState } from 'react';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import type { Language } from '@/lib/i18n';

export default function PrivacyPage() {
  const [currentLang, setCurrentLang] = useState<Language>('en');

  return (
    <div className="flex min-h-screen flex-col">
      <Header currentLang={currentLang} onLanguageChange={setCurrentLang} />

      <main className="flex-1">
        <div className="container mx-auto px-4 py-16">
          <div className="mx-auto max-w-3xl">
            <h1 className="mb-4 text-4xl font-bold">Privacy Policy</h1>
            <p className="mb-8 text-muted-foreground">
              Last updated: November 5, 2024
            </p>

            <div className="prose prose-slate max-w-none">
              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Introduction</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  AudioScribe ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our audio transcription and summarization service.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Information We Collect</h2>
                <h3 className="mb-3 text-xl font-semibold">Account Information</h3>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  When you create an account, we collect your email address and password. We use this information to authenticate your account and provide our services.
                </p>
                <h3 className="mb-3 text-xl font-semibold">Audio Files</h3>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  We temporarily store the audio files you upload for transcription and summarization. These files are encrypted during upload, processing, and storage.
                </p>
                <h3 className="mb-3 text-xl font-semibold">Usage Data</h3>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  We collect information about how you use our service, including transcription frequency, file duration, and feature usage. This helps us improve our service.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">How We Use Your Information</h2>
                <ul className="mb-4 list-disc space-y-2 pl-6 text-muted-foreground">
                  <li>To provide and maintain our transcription and summarization services</li>
                  <li>To process your audio files and generate transcriptions and summaries</li>
                  <li>To manage your account and subscription</li>
                  <li>To communicate with you about service updates and support</li>
                  <li>To improve our AI models and service quality</li>
                  <li>To detect and prevent fraud or abuse</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Data Security</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  We implement industry-standard security measures to protect your data:
                </p>
                <ul className="mb-4 list-disc space-y-2 pl-6 text-muted-foreground">
                  <li>End-to-end encryption for all file uploads and storage</li>
                  <li>Secure data centers with physical and digital security controls</li>
                  <li>Regular security audits and vulnerability assessments</li>
                  <li>Limited employee access to user data</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Data Retention</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  Your audio files and transcriptions are automatically deleted according to your plan:
                </p>
                <ul className="mb-4 list-disc space-y-2 pl-6 text-muted-foreground">
                  <li>Free plan: Files deleted after 7 days</li>
                  <li>Pro plan: Files deleted after 30 days</li>
                </ul>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  Account information is retained until you delete your account. Usage analytics are retained for service improvement purposes.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">AI Training</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  We do not use your audio files or transcriptions to train our AI models. Your content remains private and is never shared with third parties for training purposes.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Your Rights</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  You have the right to:
                </p>
                <ul className="mb-4 list-disc space-y-2 pl-6 text-muted-foreground">
                  <li>Access your personal information</li>
                  <li>Correct inaccurate information</li>
                  <li>Delete your account and associated data</li>
                  <li>Export your data in a portable format</li>
                  <li>Opt out of marketing communications</li>
                </ul>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">GDPR Compliance</h2>
                <p className="mb-4 leading-relaxed text-muted-foreground">
                  We are fully compliant with the General Data Protection Regulation (GDPR). If you are located in the European Economic Area, you have additional rights regarding your personal data.
                </p>
              </section>

              <section className="mb-8">
                <h2 className="mb-4 text-2xl font-semibold">Contact Us</h2>
                <p className="leading-relaxed text-muted-foreground">
                  If you have questions about this Privacy Policy, please contact us at privacy@audioscribe.app.
                </p>
              </section>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
