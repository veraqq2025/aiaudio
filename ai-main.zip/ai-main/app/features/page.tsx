'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import {
  Radio,
  Sparkles,
  FileText,
  Download,
  Clock,
  Shield,
  Zap,
  Languages,
  Brain,
  CheckCircle2,
  Target,
  ListChecks,
  ArrowRight,
} from 'lucide-react';
import type { Language } from '@/lib/i18n';

export default function FeaturesPage() {
  const [currentLang, setCurrentLang] = useState<Language>('en');

  return (
    <div className="flex min-h-screen flex-col">
      <Header currentLang={currentLang} onLanguageChange={setCurrentLang} />

      <main className="flex-1">
        <section className="border-b bg-gradient-to-b from-background to-muted/20 py-20">
          <div className="container mx-auto px-4">
            <div className="mx-auto max-w-3xl text-center">
              <h1 className="mb-6 text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
                Everything You Need for
                <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent"> Professional Audio Analysis</span>
              </h1>
              <p className="mb-8 text-lg text-muted-foreground sm:text-xl">
                Powerful features designed for journalists, sales professionals, and anyone who works with long-form audio content.
              </p>
              <Link href="/app/upload">
                <Button size="lg" className="h-12 px-8">
                  Start Free Trial
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <section className="border-b py-20">
          <div className="container mx-auto px-4">
            <div className="mb-16 text-center">
              <h2 className="mb-4 text-3xl font-bold sm:text-4xl">Core Features</h2>
              <p className="text-lg text-muted-foreground">
                Professional-grade tools to transform your audio workflow
              </p>
            </div>

            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10">
                    <Radio className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">High-Quality Transcription</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    State-of-the-art AI transcription with industry-leading accuracy. Handles accents, background noise, and multiple speakers with ease.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-accent/10">
                    <Brain className="h-7 w-7 text-accent" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">AI-Powered Summaries</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Get intelligent summaries with key insights, action items, and important quotes. Our AI understands context and extracts what matters.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10">
                    <Zap className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Lightning Fast Processing</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Process audio up to 10x faster than real-time. Get your transcriptions and summaries in minutes, not hours.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-accent/10">
                    <FileText className="h-7 w-7 text-accent" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Specialized Templates</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Choose from templates designed for interviews, sales calls, or general use. Each optimized for different professional needs.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10">
                    <Download className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Multiple Export Formats</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Export as TXT, DOCX, or PDF. Choose the format that fits your workflow and share easily with your team.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2 transition-all hover:border-primary hover:shadow-lg">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-accent/10">
                    <Languages className="h-7 w-7 text-accent" />
                  </div>
                  <h3 className="mb-3 text-xl font-semibold">Multiple Audio Formats</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    Support for MP3, M4A, WAV, OGG, and FLAC. Upload your files in any format without conversion hassles.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="border-b bg-muted/30 py-20">
          <div className="container mx-auto px-4">
            <div className="mb-16 text-center">
              <h2 className="mb-4 text-3xl font-bold sm:text-4xl">Template Capabilities</h2>
              <p className="text-lg text-muted-foreground">
                Specialized AI summaries tailored to your professional needs
              </p>
            </div>

            <div className="grid gap-8 lg:grid-cols-3">
              <Card className="border-2">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10">
                    <Sparkles className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="mb-4 text-2xl font-semibold">Universal Template</h3>
                  <ul className="space-y-3 text-sm text-muted-foreground">
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Core content overview with context</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Key insights with importance explanations</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Organized by theme or timeline</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Action items checklist</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Quotable moments extraction</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Topic tags and categorization</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-2">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-accent/10">
                    <FileText className="h-7 w-7 text-accent" />
                  </div>
                  <h3 className="mb-4 text-2xl font-semibold">Interview Template</h3>
                  <ul className="space-y-3 text-sm text-muted-foreground">
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Interviewee info and key themes</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Best quotes with usage context</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Topic-organized insights</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Fact-checking checklist</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Article structure suggestions</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Follow-up questions list</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="border-2">
                <CardContent className="p-8">
                  <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-lg bg-primary/10">
                    <Target className="h-7 w-7 text-primary" />
                  </div>
                  <h3 className="mb-4 text-2xl font-semibold">Sales Template</h3>
                  <ul className="space-y-3 text-sm text-muted-foreground">
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Client info and deal stage assessment</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Needs analysis breakdown</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Objection tracking with responses</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Budget and decision-maker insights</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Action items for both parties</span>
                    </li>
                    <li className="flex items-start">
                      <CheckCircle2 className="mr-2 mt-0.5 h-4 w-4 flex-shrink-0 text-accent" />
                      <span>Deal probability and risk analysis</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="border-b py-20">
          <div className="container mx-auto px-4">
            <div className="mb-16 text-center">
              <h2 className="mb-4 text-3xl font-bold sm:text-4xl">Security & Privacy</h2>
              <p className="text-lg text-muted-foreground">
                Your data security is our top priority
              </p>
            </div>

            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
              <Card className="border-2">
                <CardContent className="p-6">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-accent/10">
                    <Shield className="h-6 w-6 text-accent" />
                  </div>
                  <h3 className="mb-2 text-lg font-semibold">End-to-End Encryption</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    All files encrypted during upload, processing, and storage.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2">
                <CardContent className="p-6">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                    <Clock className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="mb-2 text-lg font-semibold">Auto-Deletion</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Files automatically deleted after 7 days (free) or 30 days (paid).
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2">
                <CardContent className="p-6">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-accent/10">
                    <ListChecks className="h-6 w-6 text-accent" />
                  </div>
                  <h3 className="mb-2 text-lg font-semibold">GDPR Compliant</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Fully compliant with international data protection standards.
                  </p>
                </CardContent>
              </Card>

              <Card className="border-2">
                <CardContent className="p-6">
                  <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                    <Shield className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="mb-2 text-lg font-semibold">Private Processing</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Your data is never used for model training or shared with third parties.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="mx-auto max-w-3xl rounded-2xl border-2 border-primary bg-gradient-to-br from-primary/5 to-accent/5 p-12 text-center shadow-xl">
              <h2 className="mb-4 text-3xl font-bold sm:text-4xl">
                Ready to Experience These Features?
              </h2>
              <p className="mb-8 text-lg text-muted-foreground">
                Start with 3 free transcriptions. No credit card required.
              </p>
              <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Link href="/app/upload">
                  <Button size="lg" className="h-12 px-8">
                    Try Free Now
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/pricing">
                  <Button size="lg" variant="outline" className="h-12 px-8">
                    View Pricing
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
