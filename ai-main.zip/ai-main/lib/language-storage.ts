import type { Language } from './i18n';

const LANGUAGE_KEY = 'preferred-language';

export const saveLanguagePreference = (lang: Language) => {
  if (typeof window !== 'undefined') {
    localStorage.setItem(LANGUAGE_KEY, lang);
  }
};

export const getLanguagePreference = (): Language | null => {
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem(LANGUAGE_KEY);
    return saved as Language | null;
  }
  return null;
};

export const detectBrowserLanguage = (): Language => {
  if (typeof window === 'undefined') return 'en';

  const browserLang = navigator.language.toLowerCase();

  if (browserLang.startsWith('zh')) return 'zh';
  if (browserLang.startsWith('ja')) return 'ja';
  if (browserLang.startsWith('ko')) return 'ko';
  if (browserLang.startsWith('es')) return 'es';
  if (browserLang.startsWith('fr')) return 'fr';
  if (browserLang.startsWith('de')) return 'de';

  return 'en';
};

export const getInitialLanguage = (): Language => {
  const saved = getLanguagePreference();
  if (saved) return saved;
  return detectBrowserLanguage();
};
