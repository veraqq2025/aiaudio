'use client';

import { useEffect, useState } from 'react';
import { X, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { languages, type Language } from '@/lib/i18n';

interface LanguageDetectorProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
}

const DISMISSED_KEY = 'language-banner-dismissed';

export function LanguageDetector({ currentLang, onLanguageChange }: LanguageDetectorProps) {
  const [suggestedLang, setSuggestedLang] = useState<Language | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const dismissed = localStorage.getItem(DISMISSED_KEY);
    if (dismissed) return;

    const browserLang = navigator.language.toLowerCase();
    let detectedLang: Language | null = null;

    if (browserLang.startsWith('zh')) {
      detectedLang = 'zh';
    } else if (browserLang.startsWith('ja')) {
      detectedLang = 'ja';
    } else if (browserLang.startsWith('ko')) {
      detectedLang = 'ko';
    } else if (browserLang.startsWith('es')) {
      detectedLang = 'es';
    } else if (browserLang.startsWith('fr')) {
      detectedLang = 'fr';
    } else if (browserLang.startsWith('de')) {
      detectedLang = 'de';
    }

    if (detectedLang && detectedLang !== currentLang) {
      setSuggestedLang(detectedLang);
      setIsVisible(true);
    }
  }, [currentLang]);

  const handleSwitch = () => {
    if (suggestedLang) {
      onLanguageChange(suggestedLang);
      setIsVisible(false);
      localStorage.setItem(DISMISSED_KEY, 'true');
    }
  };

  const handleDismiss = () => {
    setIsVisible(false);
    localStorage.setItem(DISMISSED_KEY, 'true');
  };

  if (!isVisible || !suggestedLang) return null;

  const getMessage = () => {
    switch (suggestedLang) {
      case 'zh':
        return '我们检测到您可能更适合用 简体中文';
      case 'ja':
        return '日本語に切り替えますか？';
      case 'ko':
        return '한국어로 전환하시겠습니까?';
      case 'es':
        return '¿Le gustaría cambiar a Español?';
      case 'fr':
        return 'Voulez-vous basculer en Français?';
      case 'de':
        return 'Möchten Sie zu Deutsch wechseln?';
      default:
        return `Switch to ${languages[suggestedLang].name}?`;
    }
  };

  const getSwitchButton = () => {
    switch (suggestedLang) {
      case 'zh':
        return '切换到 简体中文';
      case 'ja':
        return '日本語に切り替え';
      case 'ko':
        return '한국어로 전환';
      case 'es':
        return 'Cambiar a Español';
      case 'fr':
        return 'Basculer en Français';
      case 'de':
        return 'Zu Deutsch wechseln';
      default:
        return `Switch to ${languages[suggestedLang].name}`;
    }
  };

  return (
    <div className="fixed bottom-6 left-1/2 z-50 -translate-x-1/2 animate-in slide-in-from-bottom-5">
      <div className="flex items-center gap-4 rounded-full border border-primary/20 bg-white px-6 py-3 shadow-lg backdrop-blur-sm">
        <Globe className="h-5 w-5 text-primary" />
        <p className="text-sm font-medium text-[#1a1a2e]">{getMessage()}</p>
        <div className="flex items-center gap-2">
          <Button
            onClick={handleSwitch}
            size="sm"
            className="h-8 rounded-full bg-[#5b4eff] px-4 text-sm font-medium hover:bg-[#4a3dee]"
          >
            {getSwitchButton()}
          </Button>
          <button
            onClick={handleDismiss}
            className="rounded-full p-1 transition-colors hover:bg-gray-100"
            aria-label="Dismiss"
          >
            <X className="h-4 w-4 text-gray-500" />
          </button>
        </div>
      </div>
    </div>
  );
}
