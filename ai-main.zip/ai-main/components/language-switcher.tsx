'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Globe } from 'lucide-react';
import { languages, type Language } from '@/lib/i18n';

interface LanguageSwitcherProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
}

export function LanguageSwitcher({ currentLang, onLanguageChange }: LanguageSwitcherProps) {
  const getCurrentLangCode = () => {
    const codes: Record<Language, string> = {
      en: 'EN',
      zh: '中文',
      ja: '日本語',
      ko: '한국어',
      es: 'ES',
      fr: 'FR',
      de: 'DE',
    };
    return codes[currentLang];
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2 font-medium text-[#1a1a2e]">
          <Globe className="h-4 w-4" />
          <span>{getCurrentLangCode()}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        {(Object.keys(languages) as Language[]).map((lang) => (
          <DropdownMenuItem
            key={lang}
            onClick={() => onLanguageChange(lang)}
            className={`cursor-pointer ${lang === currentLang ? 'bg-accent' : ''}`}
          >
            <span className="mr-2">{languages[lang].flag}</span>
            <span>{languages[lang].name}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
