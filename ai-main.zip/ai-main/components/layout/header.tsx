'use client';

import Link from 'next/link';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Sparkles, Menu, X } from 'lucide-react';
import { LanguageSwitcher } from '@/components/language-switcher';
import type { Language } from '@/lib/i18n';

interface HeaderProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
  translations?: any;
}

export function Header({ currentLang, onLanguageChange, translations }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isScrollingDown, setIsScrollingDown] = useState(false);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    let ticking = false;

    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          const currentScrollY = window.scrollY;

          setIsScrolled(currentScrollY > 20);

          if (currentScrollY > lastScrollY && currentScrollY > 100) {
            setIsScrollingDown(true);
          } else {
            setIsScrollingDown(false);
          }

          setLastScrollY(currentScrollY);
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
    setMobileMenuOpen(false);
  };

  const navItems: Array<{
    label: string;
    href?: string;
    type?: string;
    items?: Array<{ label: string; href: string }>;
    action?: () => void;
  }> = [
    { label: translations?.nav?.features || 'Features', href: '/features' },
    { label: translations?.nav?.useCases || 'Use Cases', type: 'dropdown', items: [
      { label: translations?.nav?.interview || 'Interview', href: '/use-cases/interview' },
      { label: translations?.nav?.sales || 'Sales', href: '/use-cases/sales' },
    ]},
    { label: translations?.nav?.pricing || 'Pricing', action: () => scrollToSection('pricing') },
    { label: translations?.nav?.faq || 'FAQ', action: () => scrollToSection('faq') },
  ];

  return (
    <header
      className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        isScrollingDown && isScrolled ? '-translate-y-full' : 'translate-y-0'
      } ${
        isScrolled
          ? 'border-b border-primary/10 bg-white/95 shadow-sm backdrop-blur-xl'
          : 'border-b border-transparent bg-white/60 backdrop-blur-md'
      }`}
    >
      <nav className="container mx-auto flex h-16 items-center justify-between px-4 md:h-20 md:px-6">
        <Link href="/" className="group flex items-center space-x-2 transition-transform duration-300 hover:scale-105">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 transition-all duration-300 group-hover:shadow-lg group-hover:shadow-primary/20 md:h-11 md:w-11">
            <Sparkles className="h-5 w-5 text-primary transition-transform duration-300 group-hover:rotate-12 md:h-6 md:w-6" />
          </div>
          <span className="text-xl font-bold text-[#1a1a2e] transition-colors duration-300 group-hover:text-primary md:text-2xl">
            AudioScribe
          </span>
        </Link>

        <div className="hidden items-center space-x-1 lg:flex">
          {navItems.map((item, index) => (
            item.type === 'dropdown' ? (
              <div key={index} className="group relative">
                <button className="rounded-lg px-4 py-2 text-sm font-medium text-[#1a1a2e] transition-all duration-200 hover:bg-primary/5 hover:text-primary">
                  {item.label}
                  <span className="ml-1 inline-block transition-transform duration-200 group-hover:rotate-180">▾</span>
                </button>
                <div className="absolute left-0 top-full mt-2 w-48 scale-95 rounded-xl border border-primary/10 bg-white/95 opacity-0 shadow-xl backdrop-blur-xl transition-all duration-200 group-hover:scale-100 group-hover:opacity-100">
                  {item.items?.map((subItem, subIndex) => (
                    <Link
                      key={subIndex}
                      href={subItem.href}
                      className="block px-4 py-3 text-sm font-medium text-[#1a1a2e] transition-all duration-200 first:rounded-t-xl last:rounded-b-xl hover:bg-primary/5 hover:text-primary"
                    >
                      {subItem.label}
                    </Link>
                  ))}
                </div>
              </div>
            ) : item.action ? (
              <button
                key={index}
                onClick={item.action}
                className="rounded-lg px-4 py-2 text-sm font-medium text-[#1a1a2e] transition-all duration-200 hover:bg-primary/5 hover:text-primary"
              >
                {item.label}
              </button>
            ) : item.href ? (
              <Link
                key={index}
                href={item.href}
                className="rounded-lg px-4 py-2 text-sm font-medium text-[#1a1a2e] transition-all duration-200 hover:bg-primary/5 hover:text-primary"
              >
                {item.label}
              </Link>
            ) : null
          ))}
        </div>

        <div className="flex items-center space-x-2 md:space-x-3">
          <Link href="/auth/login" className="hidden md:block">
            <Button variant="ghost" size="sm" className="font-medium text-[#1a1a2e] transition-all duration-200 hover:bg-primary/5 hover:text-primary">
              {translations?.nav?.login || 'Login'}
            </Button>
          </Link>

          <div className="hidden md:block">
            <LanguageSwitcher currentLang={currentLang} onLanguageChange={onLanguageChange} />
          </div>

          <Link href="/app/upload">
            <Button
              size="sm"
              className="group relative overflow-hidden bg-gradient-to-r from-primary to-primary/90 font-medium shadow-md shadow-primary/30 transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-primary/40"
            >
              <span className="relative z-10">{translations?.nav?.tryFree || 'Try Free'}</span>
              <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-500 group-hover:translate-x-full"></div>
            </Button>
          </Link>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="rounded-lg p-2 text-[#1a1a2e] transition-all duration-200 hover:bg-primary/5 lg:hidden"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </nav>

      {mobileMenuOpen && (
        <div className="border-t border-primary/10 bg-white/95 backdrop-blur-xl lg:hidden">
          <div className="container mx-auto space-y-1 px-4 py-4">
            {navItems.map((item, index) => (
              item.type === 'dropdown' ? (
                <div key={index} className="space-y-1">
                  <div className="px-4 py-2 text-sm font-semibold text-muted-foreground">
                    {item.label}
                  </div>
                  {item.items?.map((subItem, subIndex) => (
                    <Link
                      key={subIndex}
                      href={subItem.href}
                      onClick={() => setMobileMenuOpen(false)}
                      className="block rounded-lg px-6 py-2 text-sm font-medium text-[#1a1a2e] transition-all duration-200 hover:bg-primary/5 hover:text-primary"
                    >
                      {subItem.label}
                    </Link>
                  ))}
                </div>
              ) : item.action ? (
                <button
                  key={index}
                  onClick={item.action}
                  className="block w-full rounded-lg px-4 py-3 text-left text-sm font-medium text-[#1a1a2e] transition-all duration-200 hover:bg-primary/5 hover:text-primary"
                >
                  {item.label}
                </button>
              ) : item.href ? (
                <Link
                  key={index}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="block rounded-lg px-4 py-3 text-sm font-medium text-[#1a1a2e] transition-all duration-200 hover:bg-primary/5 hover:text-primary"
                >
                  {item.label}
                </Link>
              ) : null
            ))}
            <Link
              href="/auth/login"
              onClick={() => setMobileMenuOpen(false)}
              className="block rounded-lg px-4 py-3 text-sm font-medium text-[#1a1a2e] transition-all duration-200 hover:bg-primary/5 hover:text-primary"
            >
              {translations?.nav?.login || 'Login'}
            </Link>
            <div className="px-4 py-2">
              <LanguageSwitcher currentLang={currentLang} onLanguageChange={onLanguageChange} />
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
